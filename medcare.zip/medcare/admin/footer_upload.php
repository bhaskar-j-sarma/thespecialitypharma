<!-- <script src="vendor/jquery/dist/jquery.min.js"></script>
<script src="vendor/jquery-ui/jquery-ui.min.js"></script>
<script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script> -->

<!-- The Templates plugin is included to render the upload/download listings -->
<script src="upload_scripts/js/tmpl.min.js"></script>
<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
<script src="upload_scripts/js/load-image.all.min.js"></script>
<!-- The Canvas to Blob plugin is included for image resizing functionality -->
<script src="upload_scripts/js/canvas-to-blob.min.js"></script>
<!-- blueimp Gallery script -->
<script src="upload_scripts/js/jquery.blueimp-gallery.min.js"></script>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<script src="upload_scripts/js/jquery.iframe-transport.js"></script>
<!-- The basic File Upload plugin -->
<script src="upload_scripts/js/jquery.fileupload.js"></script>
<!-- The File Upload processing plugin -->
<script src="upload_scripts/js/jquery.fileupload-process.js"></script>
<!-- The File Upload image preview & resize plugin -->
<script src="upload_scripts/js/jquery.fileupload-image.js"></script>
<!-- The File Upload validation plugin -->
<script src="upload_scripts/js/jquery.fileupload-validate.js"></script>
<!-- The File Upload user interface plugin -->
<script src="upload_scripts/js/jquery.fileupload-ui.js"></script>
<!-- The main application script -->
<script src="upload_scripts/js/upload_main.js"></script>
<!-- The XDomainRequest Transport is included for cross-domain file deletion for IE 8 and IE 9 -->
<!--[if (gte IE 8)&(lt IE 10)]>
<script src="js/cors/jquery.xdr-transport.js"></script>
<![endif]-->