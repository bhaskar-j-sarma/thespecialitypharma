!function(a) {
    "use strict";
    "function" == typeof define && define.amd ? define([ "./blueimp-helper" ], a) : (window.blueimp = window.blueimp || {}, 
    window.blueimp.Gallery = a(window.blueimp.helper || window.jQuery));
}(function(a) {
    "use strict";
    function b(a, c) {
        return void 0 === document.body.style.maxHeight ? null : this && this.options === b.prototype.options ? a && a.length ? (this.list = a, 
        this.num = a.length, this.initOptions(c), void this.initialize()) : void this.console.log("blueimp Gallery: No or empty list provided as first argument.", a) : new b(a, c);
    }
    return a.extend(b.prototype, {
        options: {
            container: "#blueimp-gallery",
            slidesContainer: "div",
            titleElement: "h3",
            displayClass: "blueimp-gallery-display",
            controlsClass: "blueimp-gallery-controls",
            singleClass: "blueimp-gallery-single",
            leftEdgeClass: "blueimp-gallery-left",
            rightEdgeClass: "blueimp-gallery-right",
            playingClass: "blueimp-gallery-playing",
            slideClass: "slide",
            slideLoadingClass: "slide-loading",
            slideErrorClass: "slide-error",
            slideContentClass: "slide-content",
            toggleClass: "toggle",
            prevClass: "prev",
            nextClass: "next",
            closeClass: "close",
            playPauseClass: "play-pause",
            typeProperty: "type",
            titleProperty: "title",
            urlProperty: "href",
            srcsetProperty: "urlset",
            displayTransition: !0,
            clearSlides: !0,
            stretchImages: !1,
            toggleControlsOnReturn: !0,
            toggleControlsOnSlideClick: !0,
            toggleSlideshowOnSpace: !0,
            enableKeyboardNavigation: !0,
            closeOnEscape: !0,
            closeOnSlideClick: !0,
            closeOnSwipeUpOrDown: !0,
            emulateTouchEvents: !0,
            stopTouchEventsPropagation: !1,
            hidePageScrollbars: !0,
            disableScroll: !0,
            carousel: !1,
            continuous: !0,
            unloadElements: !0,
            startSlideshow: !1,
            slideshowInterval: 5e3,
            index: 0,
            preloadRange: 2,
            transitionSpeed: 400,
            slideshowTransitionSpeed: void 0,
            event: void 0,
            onopen: void 0,
            onopened: void 0,
            onslide: void 0,
            onslideend: void 0,
            onslidecomplete: void 0,
            onclose: void 0,
            onclosed: void 0
        },
        carouselOptions: {
            hidePageScrollbars: !1,
            toggleControlsOnReturn: !1,
            toggleSlideshowOnSpace: !1,
            enableKeyboardNavigation: !1,
            closeOnEscape: !1,
            closeOnSlideClick: !1,
            closeOnSwipeUpOrDown: !1,
            disableScroll: !1,
            startSlideshow: !0
        },
        console: window.console && "function" == typeof window.console.log ? window.console : {
            log: function() {}
        },
        support: function(b) {
            function c() {
                var a, c, d = e.transition;
                document.body.appendChild(b), d && (a = d.name.slice(0, -9) + "ransform", void 0 !== b.style[a] && (b.style[a] = "translateZ(0)", 
                c = window.getComputedStyle(b).getPropertyValue(d.prefix + "transform"), e.transform = {
                    prefix: d.prefix,
                    name: a,
                    translate: !0,
                    translateZ: !!c && "none" !== c
                })), void 0 !== b.style.backgroundSize && (e.backgroundSize = {}, b.style.backgroundSize = "contain", 
                e.backgroundSize.contain = "contain" === window.getComputedStyle(b).getPropertyValue("background-size"), 
                b.style.backgroundSize = "cover", e.backgroundSize.cover = "cover" === window.getComputedStyle(b).getPropertyValue("background-size")), 
                document.body.removeChild(b);
            }
            var d, e = {
                touch: void 0 !== window.ontouchstart || window.DocumentTouch && document instanceof DocumentTouch
            }, f = {
                webkitTransition: {
                    end: "webkitTransitionEnd",
                    prefix: "-webkit-"
                },
                MozTransition: {
                    end: "transitionend",
                    prefix: "-moz-"
                },
                OTransition: {
                    end: "otransitionend",
                    prefix: "-o-"
                },
                transition: {
                    end: "transitionend",
                    prefix: ""
                }
            };
            for (d in f) if (f.hasOwnProperty(d) && void 0 !== b.style[d]) {
                e.transition = f[d], e.transition.name = d;
                break;
            }
            return document.body ? c() : a(document).on("DOMContentLoaded", c), e;
        }(document.createElement("div")),
        requestAnimationFrame: window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame,
        initialize: function() {
            return this.initStartIndex(), this.initWidget() === !1 ? !1 : (this.initEventListeners(), 
            this.onslide(this.index), this.ontransitionend(), void (this.options.startSlideshow && this.play()));
        },
        slide: function(a, b) {
            window.clearTimeout(this.timeout);
            var c, d, e, f = this.index;
            if (f !== a && 1 !== this.num) {
                if (b || (b = this.options.transitionSpeed), this.support.transform) {
                    for (this.options.continuous || (a = this.circle(a)), c = Math.abs(f - a) / (f - a), 
                    this.options.continuous && (d = c, c = -this.positions[this.circle(a)] / this.slideWidth, 
                    c !== d && (a = -c * this.num + a)), e = Math.abs(f - a) - 1; e; ) e -= 1, this.move(this.circle((a > f ? a : f) - e - 1), this.slideWidth * c, 0);
                    a = this.circle(a), this.move(f, this.slideWidth * c, b), this.move(a, 0, b), this.options.continuous && this.move(this.circle(a - c), -(this.slideWidth * c), 0);
                } else a = this.circle(a), this.animate(f * -this.slideWidth, a * -this.slideWidth, b);
                this.onslide(a);
            }
        },
        getIndex: function() {
            return this.index;
        },
        getNumber: function() {
            return this.num;
        },
        prev: function() {
            (this.options.continuous || this.index) && this.slide(this.index - 1);
        },
        next: function() {
            (this.options.continuous || this.index < this.num - 1) && this.slide(this.index + 1);
        },
        play: function(a) {
            var b = this;
            window.clearTimeout(this.timeout), this.interval = a || this.options.slideshowInterval, 
            this.elements[this.index] > 1 && (this.timeout = this.setTimeout(!this.requestAnimationFrame && this.slide || function(a, c) {
                b.animationFrameId = b.requestAnimationFrame.call(window, function() {
                    b.slide(a, c);
                });
            }, [ this.index + 1, this.options.slideshowTransitionSpeed ], this.interval)), this.container.addClass(this.options.playingClass);
        },
        pause: function() {
            window.clearTimeout(this.timeout), this.interval = null, this.container.removeClass(this.options.playingClass);
        },
        add: function(a) {
            var b;
            for (a.concat || (a = Array.prototype.slice.call(a)), this.list.concat || (this.list = Array.prototype.slice.call(this.list)), 
            this.list = this.list.concat(a), this.num = this.list.length, this.num > 2 && null === this.options.continuous && (this.options.continuous = !0, 
            this.container.removeClass(this.options.leftEdgeClass)), this.container.removeClass(this.options.rightEdgeClass).removeClass(this.options.singleClass), 
            b = this.num - a.length; b < this.num; b += 1) this.addSlide(b), this.positionSlide(b);
            this.positions.length = this.num, this.initSlides(!0);
        },
        resetSlides: function() {
            this.slidesContainer.empty(), this.unloadAllSlides(), this.slides = [];
        },
        handleClose: function() {
            var a = this.options;
            this.destroyEventListeners(), this.pause(), this.container[0].style.display = "none", 
            this.container.removeClass(a.displayClass).removeClass(a.singleClass).removeClass(a.leftEdgeClass).removeClass(a.rightEdgeClass), 
            a.hidePageScrollbars && (document.body.style.overflow = this.bodyOverflowStyle), 
            this.options.clearSlides && this.resetSlides(), this.options.onclosed && this.options.onclosed.call(this);
        },
        close: function() {
            function a(c) {
                c.target === b.container[0] && (b.container.off(b.support.transition.end, a), b.handleClose());
            }
            var b = this;
            this.options.onclose && this.options.onclose.call(this), this.support.transition && this.options.displayTransition ? (this.container.on(this.support.transition.end, a), 
            this.container.removeClass(this.options.displayClass)) : this.handleClose();
        },
        circle: function(a) {
            return (this.num + a % this.num) % this.num;
        },
        move: function(a, b, c) {
            this.translateX(a, b, c), this.positions[a] = b;
        },
        translate: function(a, b, c, d) {
            var e = this.slides[a].style, f = this.support.transition, g = this.support.transform;
            e[f.name + "Duration"] = d + "ms", e[g.name] = "translate(" + b + "px, " + c + "px)" + (g.translateZ ? " translateZ(0)" : "");
        },
        translateX: function(a, b, c) {
            this.translate(a, b, 0, c);
        },
        translateY: function(a, b, c) {
            this.translate(a, 0, b, c);
        },
        animate: function(a, b, c) {
            if (!c) return void (this.slidesContainer[0].style.left = b + "px");
            var d = this, e = new Date().getTime(), f = window.setInterval(function() {
                var g = new Date().getTime() - e;
                return g > c ? (d.slidesContainer[0].style.left = b + "px", d.ontransitionend(), 
                void window.clearInterval(f)) : void (d.slidesContainer[0].style.left = (b - a) * (Math.floor(g / c * 100) / 100) + a + "px");
            }, 4);
        },
        preventDefault: function(a) {
            a.preventDefault ? a.preventDefault() : a.returnValue = !1;
        },
        stopPropagation: function(a) {
            a.stopPropagation ? a.stopPropagation() : a.cancelBubble = !0;
        },
        onresize: function() {
            this.initSlides(!0);
        },
        onmousedown: function(a) {
            a.which && 1 === a.which && "VIDEO" !== a.target.nodeName && (a.preventDefault(), 
            (a.originalEvent || a).touches = [ {
                pageX: a.pageX,
                pageY: a.pageY
            } ], this.ontouchstart(a));
        },
        onmousemove: function(a) {
            this.touchStart && ((a.originalEvent || a).touches = [ {
                pageX: a.pageX,
                pageY: a.pageY
            } ], this.ontouchmove(a));
        },
        onmouseup: function(a) {
            this.touchStart && (this.ontouchend(a), delete this.touchStart);
        },
        onmouseout: function(b) {
            if (this.touchStart) {
                var c = b.target, d = b.relatedTarget;
                (!d || d !== c && !a.contains(c, d)) && this.onmouseup(b);
            }
        },
        ontouchstart: function(a) {
            this.options.stopTouchEventsPropagation && this.stopPropagation(a);
            var b = (a.originalEvent || a).touches[0];
            this.touchStart = {
                x: b.pageX,
                y: b.pageY,
                time: Date.now()
            }, this.isScrolling = void 0, this.touchDelta = {};
        },
        ontouchmove: function(a) {
            this.options.stopTouchEventsPropagation && this.stopPropagation(a);
            var b, c, d = (a.originalEvent || a).touches[0], e = (a.originalEvent || a).scale, f = this.index;
            if (!(d.length > 1 || e && 1 !== e)) if (this.options.disableScroll && a.preventDefault(), 
            this.touchDelta = {
                x: d.pageX - this.touchStart.x,
                y: d.pageY - this.touchStart.y
            }, b = this.touchDelta.x, void 0 === this.isScrolling && (this.isScrolling = this.isScrolling || Math.abs(b) < Math.abs(this.touchDelta.y)), 
            this.isScrolling) this.options.closeOnSwipeUpOrDown && this.translateY(f, this.touchDelta.y + this.positions[f], 0); else for (a.preventDefault(), 
            window.clearTimeout(this.timeout), this.options.continuous ? c = [ this.circle(f + 1), f, this.circle(f - 1) ] : (this.touchDelta.x = b /= !f && b > 0 || f === this.num - 1 && 0 > b ? Math.abs(b) / this.slideWidth + 1 : 1, 
            c = [ f ], f && c.push(f - 1), f < this.num - 1 && c.unshift(f + 1)); c.length; ) f = c.pop(), 
            this.translateX(f, b + this.positions[f], 0);
        },
        ontouchend: function(a) {
            this.options.stopTouchEventsPropagation && this.stopPropagation(a);
            var b, c, d, e, f, g = this.index, h = this.options.transitionSpeed, i = this.slideWidth, j = Number(Date.now() - this.touchStart.time) < 250, k = j && Math.abs(this.touchDelta.x) > 20 || Math.abs(this.touchDelta.x) > i / 2, l = !g && this.touchDelta.x > 0 || g === this.num - 1 && this.touchDelta.x < 0, m = !k && this.options.closeOnSwipeUpOrDown && (j && Math.abs(this.touchDelta.y) > 20 || Math.abs(this.touchDelta.y) > this.slideHeight / 2);
            this.options.continuous && (l = !1), b = this.touchDelta.x < 0 ? -1 : 1, this.isScrolling ? m ? this.close() : this.translateY(g, 0, h) : k && !l ? (c = g + b, 
            d = g - b, e = i * b, f = -i * b, this.options.continuous ? (this.move(this.circle(c), e, 0), 
            this.move(this.circle(g - 2 * b), f, 0)) : c >= 0 && c < this.num && this.move(c, e, 0), 
            this.move(g, this.positions[g] + e, h), this.move(this.circle(d), this.positions[this.circle(d)] + e, h), 
            g = this.circle(d), this.onslide(g)) : this.options.continuous ? (this.move(this.circle(g - 1), -i, h), 
            this.move(g, 0, h), this.move(this.circle(g + 1), i, h)) : (g && this.move(g - 1, -i, h), 
            this.move(g, 0, h), g < this.num - 1 && this.move(g + 1, i, h));
        },
        ontouchcancel: function(a) {
            this.touchStart && (this.ontouchend(a), delete this.touchStart);
        },
        ontransitionend: function(a) {
            var b = this.slides[this.index];
            a && b !== a.target || (this.interval && this.play(), this.setTimeout(this.options.onslideend, [ this.index, b ]));
        },
        oncomplete: function(b) {
            var c, d = b.target || b.srcElement, e = d && d.parentNode;
            d && e && (c = this.getNodeIndex(e), a(e).removeClass(this.options.slideLoadingClass), 
            "error" === b.type ? (a(e).addClass(this.options.slideErrorClass), this.elements[c] = 3) : this.elements[c] = 2, 
            d.clientHeight > this.container[0].clientHeight && (d.style.maxHeight = this.container[0].clientHeight), 
            this.interval && this.slides[this.index] === e && this.play(), this.setTimeout(this.options.onslidecomplete, [ c, e ]));
        },
        onload: function(a) {
            this.oncomplete(a);
        },
        onerror: function(a) {
            this.oncomplete(a);
        },
        onkeydown: function(a) {
            switch (a.which || a.keyCode) {
              case 13:
                this.options.toggleControlsOnReturn && (this.preventDefault(a), this.toggleControls());
                break;

              case 27:
                this.options.closeOnEscape && (this.close(), a.stopImmediatePropagation());
                break;

              case 32:
                this.options.toggleSlideshowOnSpace && (this.preventDefault(a), this.toggleSlideshow());
                break;

              case 37:
                this.options.enableKeyboardNavigation && (this.preventDefault(a), this.prev());
                break;

              case 39:
                this.options.enableKeyboardNavigation && (this.preventDefault(a), this.next());
            }
        },
        handleClick: function(b) {
            function c(b) {
                return a(e).hasClass(b) || a(f).hasClass(b);
            }
            var d = this.options, e = b.target || b.srcElement, f = e.parentNode;
            c(d.toggleClass) ? (this.preventDefault(b), this.toggleControls()) : c(d.prevClass) ? (this.preventDefault(b), 
            this.prev()) : c(d.nextClass) ? (this.preventDefault(b), this.next()) : c(d.closeClass) ? (this.preventDefault(b), 
            this.close()) : c(d.playPauseClass) ? (this.preventDefault(b), this.toggleSlideshow()) : f === this.slidesContainer[0] ? d.closeOnSlideClick ? (this.preventDefault(b), 
            this.close()) : d.toggleControlsOnSlideClick && (this.preventDefault(b), this.toggleControls()) : f.parentNode && f.parentNode === this.slidesContainer[0] && d.toggleControlsOnSlideClick && (this.preventDefault(b), 
            this.toggleControls());
        },
        onclick: function(a) {
            return this.options.emulateTouchEvents && this.touchDelta && (Math.abs(this.touchDelta.x) > 20 || Math.abs(this.touchDelta.y) > 20) ? void delete this.touchDelta : this.handleClick(a);
        },
        updateEdgeClasses: function(a) {
            a ? this.container.removeClass(this.options.leftEdgeClass) : this.container.addClass(this.options.leftEdgeClass), 
            a === this.num - 1 ? this.container.addClass(this.options.rightEdgeClass) : this.container.removeClass(this.options.rightEdgeClass);
        },
        handleSlide: function(a) {
            this.options.continuous || this.updateEdgeClasses(a), this.loadElements(a), this.options.unloadElements && this.unloadElements(a), 
            this.setTitle(a);
        },
        onslide: function(a) {
            this.index = a, this.handleSlide(a), this.setTimeout(this.options.onslide, [ a, this.slides[a] ]);
        },
        setTitle: function(a) {
            var b = this.slides[a].firstChild.title, c = this.titleElement;
            c.length && (this.titleElement.empty(), b && c[0].appendChild(document.createTextNode(b)));
        },
        setTimeout: function(a, b, c) {
            var d = this;
            return a && window.setTimeout(function() {
                a.apply(d, b || []);
            }, c || 0);
        },
        imageFactory: function(b, c) {
            function d(b) {
                if (!e) {
                    if (b = {
                        type: b.type,
                        target: f
                    }, !f.parentNode) return h.setTimeout(d, [ b ]);
                    e = !0, a(i).off("load error", d), k && "load" === b.type && (f.style.background = 'url("' + j + '") center no-repeat', 
                    f.style.backgroundSize = k), c(b);
                }
            }
            var e, f, g, h = this, i = this.imagePrototype.cloneNode(!1), j = b, k = this.options.stretchImages;
            return "string" != typeof j && (j = this.getItemProperty(b, this.options.urlProperty), 
            g = this.getItemProperty(b, this.options.titleProperty)), k === !0 && (k = "contain"), 
            k = this.support.backgroundSize && this.support.backgroundSize[k] && k, k ? f = this.elementPrototype.cloneNode(!1) : (f = i, 
            i.draggable = !1), g && (f.title = g), a(i).on("load error", d), i.src = j, f;
        },
        createElement: function(b, c) {
            var d = b && this.getItemProperty(b, this.options.typeProperty), e = d && this[d.split("/")[0] + "Factory"] || this.imageFactory, f = b && e.call(this, b, c), g = this.getItemProperty(b, this.options.srcsetProperty);
            return f || (f = this.elementPrototype.cloneNode(!1), this.setTimeout(c, [ {
                type: "error",
                target: f
            } ])), g && f.setAttribute("srcset", g), a(f).addClass(this.options.slideContentClass), 
            f;
        },
        loadElement: function(b) {
            this.elements[b] || (this.slides[b].firstChild ? this.elements[b] = a(this.slides[b]).hasClass(this.options.slideErrorClass) ? 3 : 2 : (this.elements[b] = 1, 
            a(this.slides[b]).addClass(this.options.slideLoadingClass), this.slides[b].appendChild(this.createElement(this.list[b], this.proxyListener))));
        },
        loadElements: function(a) {
            var b, c = Math.min(this.num, 2 * this.options.preloadRange + 1), d = a;
            for (b = 0; c > b; b += 1) d += b * (b % 2 === 0 ? -1 : 1), d = this.circle(d), 
            this.loadElement(d);
        },
        unloadElements: function(a) {
            var b, c;
            for (b in this.elements) this.elements.hasOwnProperty(b) && (c = Math.abs(a - b), 
            c > this.options.preloadRange && c + this.options.preloadRange < this.num && (this.unloadSlide(b), 
            delete this.elements[b]));
        },
        addSlide: function(a) {
            var b = this.slidePrototype.cloneNode(!1);
            b.setAttribute("data-index", a), this.slidesContainer[0].appendChild(b), this.slides.push(b);
        },
        positionSlide: function(a) {
            var b = this.slides[a];
            b.style.width = this.slideWidth + "px", this.support.transform && (b.style.left = a * -this.slideWidth + "px", 
            this.move(a, this.index > a ? -this.slideWidth : this.index < a ? this.slideWidth : 0, 0));
        },
        initSlides: function(b) {
            var c, d;
            for (b || (this.positions = [], this.positions.length = this.num, this.elements = {}, 
            this.imagePrototype = document.createElement("img"), this.elementPrototype = document.createElement("div"), 
            this.slidePrototype = document.createElement("div"), a(this.slidePrototype).addClass(this.options.slideClass), 
            this.slides = this.slidesContainer[0].children, c = this.options.clearSlides || this.slides.length !== this.num), 
            this.slideWidth = this.container[0].offsetWidth, this.slideHeight = this.container[0].offsetHeight, 
            this.slidesContainer[0].style.width = this.num * this.slideWidth + "px", c && this.resetSlides(), 
            d = 0; d < this.num; d += 1) c && this.addSlide(d), this.positionSlide(d);
            this.options.continuous && this.support.transform && (this.move(this.circle(this.index - 1), -this.slideWidth, 0), 
            this.move(this.circle(this.index + 1), this.slideWidth, 0)), this.support.transform || (this.slidesContainer[0].style.left = this.index * -this.slideWidth + "px");
        },
        unloadSlide: function(a) {
            var b, c;
            b = this.slides[a], c = b.firstChild, null !== c && b.removeChild(c);
        },
        unloadAllSlides: function() {
            var a, b;
            for (a = 0, b = this.slides.length; b > a; a++) this.unloadSlide(a);
        },
        toggleControls: function() {
            var a = this.options.controlsClass;
            this.container.hasClass(a) ? this.container.removeClass(a) : this.container.addClass(a);
        },
        toggleSlideshow: function() {
            this.interval ? this.pause() : this.play();
        },
        getNodeIndex: function(a) {
            return parseInt(a.getAttribute("data-index"), 10);
        },
        getNestedProperty: function(a, b) {
            return b.replace(/\[(?:'([^']+)'|"([^"]+)"|(\d+))\]|(?:(?:^|\.)([^\.\[]+))/g, function(b, c, d, e, f) {
                var g = f || c || d || e && parseInt(e, 10);
                b && a && (a = a[g]);
            }), a;
        },
        getDataProperty: function(b, c) {
            if (b.getAttribute) {
                var d = b.getAttribute("data-" + c.replace(/([A-Z])/g, "-$1").toLowerCase());
                if ("string" == typeof d) {
                    if (/^(true|false|null|-?\d+(\.\d+)?|\{[\s\S]*\}|\[[\s\S]*\])$/.test(d)) try {
                        return a.parseJSON(d);
                    } catch (e) {}
                    return d;
                }
            }
        },
        getItemProperty: function(a, b) {
            var c = a[b];
            return void 0 === c && (c = this.getDataProperty(a, b), void 0 === c && (c = this.getNestedProperty(a, b))), 
            c;
        },
        initStartIndex: function() {
            var a, b = this.options.index, c = this.options.urlProperty;
            if (b && "number" != typeof b) for (a = 0; a < this.num; a += 1) if (this.list[a] === b || this.getItemProperty(this.list[a], c) === this.getItemProperty(b, c)) {
                b = a;
                break;
            }
            this.index = this.circle(parseInt(b, 10) || 0);
        },
        initEventListeners: function() {
            function b(a) {
                var b = c.support.transition && c.support.transition.end === a.type ? "transitionend" : a.type;
                c["on" + b](a);
            }
            var c = this, d = this.slidesContainer;
            a(window).on("resize", b), a(document.body).on("keydown", b), this.container.on("click", b), 
            this.support.touch ? d.on("touchstart touchmove touchend touchcancel", b) : this.options.emulateTouchEvents && this.support.transition && d.on("mousedown mousemove mouseup mouseout", b), 
            this.support.transition && d.on(this.support.transition.end, b), this.proxyListener = b;
        },
        destroyEventListeners: function() {
            var b = this.slidesContainer, c = this.proxyListener;
            a(window).off("resize", c), a(document.body).off("keydown", c), this.container.off("click", c), 
            this.support.touch ? b.off("touchstart touchmove touchend touchcancel", c) : this.options.emulateTouchEvents && this.support.transition && b.off("mousedown mousemove mouseup mouseout", c), 
            this.support.transition && b.off(this.support.transition.end, c);
        },
        handleOpen: function() {
            this.options.onopened && this.options.onopened.call(this);
        },
        initWidget: function() {
            function b(a) {
                a.target === c.container[0] && (c.container.off(c.support.transition.end, b), c.handleOpen());
            }
            var c = this;
            return this.container = a(this.options.container), this.container.length ? (this.slidesContainer = this.container.find(this.options.slidesContainer).first(), 
            this.slidesContainer.length ? (this.titleElement = this.container.find(this.options.titleElement).first(), 
            1 === this.num && this.container.addClass(this.options.singleClass), this.options.onopen && this.options.onopen.call(this), 
            this.support.transition && this.options.displayTransition ? this.container.on(this.support.transition.end, b) : this.handleOpen(), 
            this.options.hidePageScrollbars && (this.bodyOverflowStyle = document.body.style.overflow, 
            document.body.style.overflow = "hidden"), this.container[0].style.display = "block", 
            this.initSlides(), void this.container.addClass(this.options.displayClass)) : (this.console.log("blueimp Gallery: Slides container not found.", this.options.slidesContainer), 
            !1)) : (this.console.log("blueimp Gallery: Widget container not found.", this.options.container), 
            !1);
        },
        initOptions: function(b) {
            this.options = a.extend({}, this.options), (b && b.carousel || this.options.carousel && (!b || b.carousel !== !1)) && a.extend(this.options, this.carouselOptions), 
            a.extend(this.options, b), this.num < 3 && (this.options.continuous = this.options.continuous ? null : !1), 
            this.support.transition || (this.options.emulateTouchEvents = !1), this.options.event && this.preventDefault(this.options.event);
        }
    }), b;
}), function(a) {
    "use strict";
    "function" == typeof define && define.amd ? define([ "./blueimp-helper", "./blueimp-gallery" ], a) : a(window.blueimp.helper || window.jQuery, window.blueimp.Gallery);
}(function(a, b) {
    "use strict";
    a.extend(b.prototype.options, {
        fullScreen: !1
    });
    var c = b.prototype.initialize, d = b.prototype.close;
    return a.extend(b.prototype, {
        getFullScreenElement: function() {
            return document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement;
        },
        requestFullScreen: function(a) {
            a.requestFullscreen ? a.requestFullscreen() : a.webkitRequestFullscreen ? a.webkitRequestFullscreen() : a.mozRequestFullScreen ? a.mozRequestFullScreen() : a.msRequestFullscreen && a.msRequestFullscreen();
        },
        exitFullScreen: function() {
            document.exitFullscreen ? document.exitFullscreen() : document.webkitCancelFullScreen ? document.webkitCancelFullScreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.msExitFullscreen && document.msExitFullscreen();
        },
        initialize: function() {
            c.call(this), this.options.fullScreen && !this.getFullScreenElement() && this.requestFullScreen(this.container[0]);
        },
        close: function() {
            this.getFullScreenElement() === this.container[0] && this.exitFullScreen(), d.call(this);
        }
    }), b;
}), function(a) {
    "use strict";
    "function" == typeof define && define.amd ? define([ "./blueimp-helper", "./blueimp-gallery" ], a) : a(window.blueimp.helper || window.jQuery, window.blueimp.Gallery);
}(function(a, b) {
    "use strict";
    a.extend(b.prototype.options, {
        indicatorContainer: "ol",
        activeIndicatorClass: "active",
        thumbnailProperty: "thumbnail",
        thumbnailIndicators: !0
    });
    var c = b.prototype.initSlides, d = b.prototype.addSlide, e = b.prototype.resetSlides, f = b.prototype.handleClick, g = b.prototype.handleSlide, h = b.prototype.handleClose;
    return a.extend(b.prototype, {
        createIndicator: function(b) {
            var c, d, e = this.indicatorPrototype.cloneNode(!1), f = this.getItemProperty(b, this.options.titleProperty), g = this.options.thumbnailProperty;
            return this.options.thumbnailIndicators && (g && (c = this.getItemProperty(b, g)), 
            void 0 === c && (d = b.getElementsByTagName && a(b).find("img")[0], d && (c = d.src)), 
            c && (e.style.backgroundImage = 'url("' + c + '")')), f && (e.title = f), e;
        },
        addIndicator: function(a) {
            if (this.indicatorContainer.length) {
                var b = this.createIndicator(this.list[a]);
                b.setAttribute("data-index", a), this.indicatorContainer[0].appendChild(b), this.indicators.push(b);
            }
        },
        setActiveIndicator: function(b) {
            this.indicators && (this.activeIndicator && this.activeIndicator.removeClass(this.options.activeIndicatorClass), 
            this.activeIndicator = a(this.indicators[b]), this.activeIndicator.addClass(this.options.activeIndicatorClass));
        },
        initSlides: function(a) {
            a || (this.indicatorContainer = this.container.find(this.options.indicatorContainer), 
            this.indicatorContainer.length && (this.indicatorPrototype = document.createElement("li"), 
            this.indicators = this.indicatorContainer[0].children)), c.call(this, a);
        },
        addSlide: function(a) {
            d.call(this, a), this.addIndicator(a);
        },
        resetSlides: function() {
            e.call(this), this.indicatorContainer.empty(), this.indicators = [];
        },
        handleClick: function(a) {
            var b = a.target || a.srcElement, c = b.parentNode;
            if (c === this.indicatorContainer[0]) this.preventDefault(a), this.slide(this.getNodeIndex(b)); else {
                if (c.parentNode !== this.indicatorContainer[0]) return f.call(this, a);
                this.preventDefault(a), this.slide(this.getNodeIndex(c));
            }
        },
        handleSlide: function(a) {
            g.call(this, a), this.setActiveIndicator(a);
        },
        handleClose: function() {
            this.activeIndicator && this.activeIndicator.removeClass(this.options.activeIndicatorClass), 
            h.call(this);
        }
    }), b;
}), function(a) {
    "use strict";
    "function" == typeof define && define.amd ? define([ "./blueimp-helper", "./blueimp-gallery" ], a) : a(window.blueimp.helper || window.jQuery, window.blueimp.Gallery);
}(function(a, b) {
    "use strict";
    a.extend(b.prototype.options, {
        videoContentClass: "video-content",
        videoLoadingClass: "video-loading",
        videoPlayingClass: "video-playing",
        videoPosterProperty: "poster",
        videoSourcesProperty: "sources"
    });
    var c = b.prototype.handleSlide;
    return a.extend(b.prototype, {
        handleSlide: function(a) {
            c.call(this, a), this.playingVideo && this.playingVideo.pause();
        },
        videoFactory: function(b, c, d) {
            var e, f, g, h, i, j = this, k = this.options, l = this.elementPrototype.cloneNode(!1), m = a(l), n = [ {
                type: "error",
                target: l
            } ], o = d || document.createElement("video"), p = this.getItemProperty(b, k.urlProperty), q = this.getItemProperty(b, k.typeProperty), r = this.getItemProperty(b, k.titleProperty), s = this.getItemProperty(b, k.videoPosterProperty), t = this.getItemProperty(b, k.videoSourcesProperty);
            if (m.addClass(k.videoContentClass), r && (l.title = r), o.canPlayType) if (p && q && o.canPlayType(q)) o.src = p; else for (;t && t.length; ) if (f = t.shift(), 
            p = this.getItemProperty(f, k.urlProperty), q = this.getItemProperty(f, k.typeProperty), 
            p && q && o.canPlayType(q)) {
                o.src = p;
                break;
            }
            return s && (o.poster = s, e = this.imagePrototype.cloneNode(!1), a(e).addClass(k.toggleClass), 
            e.src = s, e.draggable = !1, l.appendChild(e)), g = document.createElement("a"), 
            g.setAttribute("target", "_blank"), d || g.setAttribute("download", r), g.href = p, 
            o.src && (o.controls = !0, (d || a(o)).on("error", function() {
                j.setTimeout(c, n);
            }).on("pause", function() {
                h = !1, m.removeClass(j.options.videoLoadingClass).removeClass(j.options.videoPlayingClass), 
                i && j.container.addClass(j.options.controlsClass), delete j.playingVideo, j.interval && j.play();
            }).on("playing", function() {
                h = !1, m.removeClass(j.options.videoLoadingClass).addClass(j.options.videoPlayingClass), 
                j.container.hasClass(j.options.controlsClass) ? (i = !0, j.container.removeClass(j.options.controlsClass)) : i = !1;
            }).on("play", function() {
                window.clearTimeout(j.timeout), h = !0, m.addClass(j.options.videoLoadingClass), 
                j.playingVideo = o;
            }), a(g).on("click", function(a) {
                j.preventDefault(a), h ? o.pause() : o.play();
            }), l.appendChild(d && d.element || o)), l.appendChild(g), this.setTimeout(c, [ {
                type: "load",
                target: l
            } ]), l;
        }
    }), b;
}), function(a) {
    "use strict";
    "function" == typeof define && define.amd ? define([ "./blueimp-helper", "./blueimp-gallery-video" ], a) : a(window.blueimp.helper || window.jQuery, window.blueimp.Gallery);
}(function(a, b) {
    "use strict";
    if (!window.postMessage) return b;
    a.extend(b.prototype.options, {
        vimeoVideoIdProperty: "vimeo",
        vimeoPlayerUrl: "//player.vimeo.com/video/VIDEO_ID?api=1&player_id=PLAYER_ID",
        vimeoPlayerIdPrefix: "vimeo-player-",
        vimeoClickToPlay: !0
    });
    var c = b.prototype.textFactory || b.prototype.imageFactory, d = function(a, b, c, d) {
        this.url = a, this.videoId = b, this.playerId = c, this.clickToPlay = d, this.element = document.createElement("div"), 
        this.listeners = {};
    }, e = 0;
    return a.extend(d.prototype, {
        canPlayType: function() {
            return !0;
        },
        on: function(a, b) {
            return this.listeners[a] = b, this;
        },
        loadAPI: function() {
            function b() {
                !d && e.playOnReady && e.play(), d = !0;
            }
            for (var c, d, e = this, f = "//f.vimeocdn.com/js/froogaloop2.min.js", g = document.getElementsByTagName("script"), h = g.length; h; ) if (h -= 1, 
            g[h].src === f) {
                c = g[h];
                break;
            }
            c || (c = document.createElement("script"), c.src = f), a(c).on("load", b), g[0].parentNode.insertBefore(c, g[0]), 
            /loaded|complete/.test(c.readyState) && b();
        },
        onReady: function() {
            var a = this;
            this.ready = !0, this.player.addEvent("play", function() {
                a.hasPlayed = !0, a.onPlaying();
            }), this.player.addEvent("pause", function() {
                a.onPause();
            }), this.player.addEvent("finish", function() {
                a.onPause();
            }), this.playOnReady && this.play();
        },
        onPlaying: function() {
            this.playStatus < 2 && (this.listeners.playing(), this.playStatus = 2);
        },
        onPause: function() {
            this.listeners.pause(), delete this.playStatus;
        },
        insertIframe: function() {
            var a = document.createElement("iframe");
            a.src = this.url.replace("VIDEO_ID", this.videoId).replace("PLAYER_ID", this.playerId), 
            a.id = this.playerId, this.element.parentNode.replaceChild(a, this.element), this.element = a;
        },
        play: function() {
            var a = this;
            this.playStatus || (this.listeners.play(), this.playStatus = 1), this.ready ? !this.hasPlayed && (this.clickToPlay || window.navigator && /iP(hone|od|ad)/.test(window.navigator.platform)) ? this.onPlaying() : this.player.api("play") : (this.playOnReady = !0, 
            window.$f ? this.player || (this.insertIframe(), this.player = $f(this.element), 
            this.player.addEvent("ready", function() {
                a.onReady();
            })) : this.loadAPI());
        },
        pause: function() {
            this.ready ? this.player.api("pause") : this.playStatus && (delete this.playOnReady, 
            this.listeners.pause(), delete this.playStatus);
        }
    }), a.extend(b.prototype, {
        VimeoPlayer: d,
        textFactory: function(a, b) {
            var f = this.options, g = this.getItemProperty(a, f.vimeoVideoIdProperty);
            return g ? (void 0 === this.getItemProperty(a, f.urlProperty) && (a[f.urlProperty] = "//vimeo.com/" + g), 
            e += 1, this.videoFactory(a, b, new d(f.vimeoPlayerUrl, g, f.vimeoPlayerIdPrefix + e, f.vimeoClickToPlay))) : c.call(this, a, b);
        }
    }), b;
}), function(a) {
    "use strict";
    "function" == typeof define && define.amd ? define([ "./blueimp-helper", "./blueimp-gallery-video" ], a) : a(window.blueimp.helper || window.jQuery, window.blueimp.Gallery);
}(function(a, b) {
    "use strict";
    if (!window.postMessage) return b;
    a.extend(b.prototype.options, {
        youTubeVideoIdProperty: "youtube",
        youTubePlayerVars: {
            wmode: "transparent"
        },
        youTubeClickToPlay: !0
    });
    var c = b.prototype.textFactory || b.prototype.imageFactory, d = function(a, b, c) {
        this.videoId = a, this.playerVars = b, this.clickToPlay = c, this.element = document.createElement("div"), 
        this.listeners = {};
    };
    return a.extend(d.prototype, {
        canPlayType: function() {
            return !0;
        },
        on: function(a, b) {
            return this.listeners[a] = b, this;
        },
        loadAPI: function() {
            var a, b = this, c = window.onYouTubeIframeAPIReady, d = "//www.youtube.com/iframe_api", e = document.getElementsByTagName("script"), f = e.length;
            for (window.onYouTubeIframeAPIReady = function() {
                c && c.apply(this), b.playOnReady && b.play();
            }; f; ) if (f -= 1, e[f].src === d) return;
            a = document.createElement("script"), a.src = d, e[0].parentNode.insertBefore(a, e[0]);
        },
        onReady: function() {
            this.ready = !0, this.playOnReady && this.play();
        },
        onPlaying: function() {
            this.playStatus < 2 && (this.listeners.playing(), this.playStatus = 2);
        },
        onPause: function() {
            b.prototype.setTimeout.call(this, this.checkSeek, null, 2e3);
        },
        checkSeek: function() {
            (this.stateChange === YT.PlayerState.PAUSED || this.stateChange === YT.PlayerState.ENDED) && (this.listeners.pause(), 
            delete this.playStatus);
        },
        onStateChange: function(a) {
            switch (a.data) {
              case YT.PlayerState.PLAYING:
                this.hasPlayed = !0, this.onPlaying();
                break;

              case YT.PlayerState.PAUSED:
              case YT.PlayerState.ENDED:
                this.onPause();
            }
            this.stateChange = a.data;
        },
        onError: function(a) {
            this.listeners.error(a);
        },
        play: function() {
            var a = this;
            this.playStatus || (this.listeners.play(), this.playStatus = 1), this.ready ? !this.hasPlayed && (this.clickToPlay || window.navigator && /iP(hone|od|ad)/.test(window.navigator.platform)) ? this.onPlaying() : this.player.playVideo() : (this.playOnReady = !0, 
            window.YT && YT.Player ? this.player || (this.player = new YT.Player(this.element, {
                videoId: this.videoId,
                playerVars: this.playerVars,
                events: {
                    onReady: function() {
                        a.onReady();
                    },
                    onStateChange: function(b) {
                        a.onStateChange(b);
                    },
                    onError: function(b) {
                        a.onError(b);
                    }
                }
            })) : this.loadAPI());
        },
        pause: function() {
            this.ready ? this.player.pauseVideo() : this.playStatus && (delete this.playOnReady, 
            this.listeners.pause(), delete this.playStatus);
        }
    }), a.extend(b.prototype, {
        YouTubePlayer: d,
        textFactory: function(a, b) {
            var e = this.options, f = this.getItemProperty(a, e.youTubeVideoIdProperty);
            return f ? (void 0 === this.getItemProperty(a, e.urlProperty) && (a[e.urlProperty] = "//www.youtube.com/watch?v=" + f), 
            void 0 === this.getItemProperty(a, e.videoPosterProperty) && (a[e.videoPosterProperty] = "//img.youtube.com/vi/" + f + "/maxresdefault.jpg"), 
            this.videoFactory(a, b, new d(f, e.youTubePlayerVars, e.youTubeClickToPlay))) : c.call(this, a, b);
        }
    }), b;
}), function(a) {
    "use strict";
    "function" == typeof define && define.amd ? define([ "jquery", "./blueimp-gallery" ], a) : a(window.jQuery, window.blueimp.Gallery);
}(function(a, b) {
    "use strict";
    a(document).on("click", "[data-gallery]", function(c) {
        var d = a(this).data("gallery"), e = a(d), f = e.length && e || a(b.prototype.options.container), g = {
            onopen: function() {
                f.data("gallery", this).trigger("open");
            },
            onopened: function() {
                f.trigger("opened");
            },
            onslide: function() {
                f.trigger("slide", arguments);
            },
            onslideend: function() {
                f.trigger("slideend", arguments);
            },
            onslidecomplete: function() {
                f.trigger("slidecomplete", arguments);
            },
            onclose: function() {
                f.trigger("close");
            },
            onclosed: function() {
                f.trigger("closed").removeData("gallery");
            }
        }, h = a.extend(f.data(), {
            container: f[0],
            index: this,
            event: c
        }, g), i = a('[data-gallery="' + d + '"]');
        return h.filter && (i = i.filter(h.filter)), new b(i, h);
    });
});