
<!-- <link rel="stylesheet" href="vendor/bootstrap/dist/css/bootstrap.css" />
<link rel="stylesheet" href="upload_scripts/css/style.css"> -->
<!-- blueimp Gallery styles -->
<link rel="stylesheet" href="upload_scripts/css/blueimp-gallery.min.css">
<!-- CSS to style the file input field as button and adjust the Bootstrap progress bars -->
<link rel="stylesheet" href="upload_scripts/css/jquery.fileupload.css">
<link rel="stylesheet" href="upload_scripts/css/jquery.fileupload-ui.css">
<!-- CSS adjustments for browsers with JavaScript disabled -->
<noscript><link rel="stylesheet" href="upload_scripts/css/jquery.fileupload-noscript.css"></noscript>
<noscript><link rel="stylesheet" href="upload_scripts/css/jquery.fileupload-ui-noscript.css"></noscript>