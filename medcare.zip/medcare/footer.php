<footer class="footer-area area-padding-top" style="background-color: aliceblue;">
        <div class="container">
            <div class="row">
                <div class="col-md-4 single-footer-widget">
                    <h4>The Speciality Pharma</h4>
                    <p>We The Speciality Pharma, from 2014, are serving our customers by wholesaling and trading a high-quality Pharmaceutical Products. Offered products range have Pharmaceutical Tablets, Pharmaceutical Capsules, and Pharmaceutical Injection.</p>
                </div>
                <div class="col-md-4 text-center single-footer-widget">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Products</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-md-4 text-center single-footer-widget">
                    <h4>Features</h4>
                    <ul>
                        <li><a href="#"><i class="ti-home"></i>&nbsp;&nbsp;Birubari, Guwahati, Kamrup, Assam</a></li>
                        <li><a href="#"><i class="ti-tablet">&nbsp;&nbsp;+91 987654321</i></a></li>
                        <li><a href="#"><i class="ti-email"></i>&nbsp;&nbsp;specialitypharma@gmail.com</a></li>
                    </ul>
                </div>
               
        </div>
        <div class="row footer-bottom d-flex justify-content-between">
            <p class="col-lg-8 col-sm-12 footer-text m-0">
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Designed by 3D Motion Creative</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
            <div class="col-lg-4 col-sm-12 footer-social">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-dribbble"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>
    </div>
</footer>